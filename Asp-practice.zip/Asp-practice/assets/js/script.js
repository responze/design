﻿gsap.from('.opt'{duration:1, y:'-100%', ease:'bounce'});
